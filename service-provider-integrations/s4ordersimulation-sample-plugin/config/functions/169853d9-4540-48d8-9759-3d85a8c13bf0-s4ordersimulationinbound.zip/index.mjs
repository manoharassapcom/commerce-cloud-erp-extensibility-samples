export const handler = (input, configuration) => {
    console.log("[s4ordersimulationInbound] input: " + JSON.stringify(input, null, 2));
    const s4Response = input?.data ?? {};
    const configMap = (configuration && typeof configuration === "object") ? configuration : {};
    const storeId = input?.commerceContext?.storeId?.trim() ?? "";
    const prefix = `${storeId}.`;

    const getConfig = key => configMap[`${prefix}${key}`]?.trim() ?? "";
    const getConfigList = key =>
        getConfig(key) ? getConfig(key).split(",").map(s => s.trim()).filter(Boolean) : [];

    const currencyCode = s4Response.TransactionCurrency ?? "";

    const STRATEGY = {
        PRICING_PROCEDURE_STEP: "PROCEDURE_STEP",
        CONDITION_TYPE:         "CONDITION_TYPE",
        SUBTOTAL:               "SUBTOTAL"
    };

    const toSubtotalField = value => `Subtotal${value}Amount`;

    const matchesPricingProcedureStep = (pe, values) =>
        values.includes(String(pe.PricingProcedureStep ?? "").trim());

    const matchesConditionType = (pe, values) =>
        values.includes(String(pe.ConditionType ?? "").trim());

    const buildDiscount = (pe, group) => {
        const calcType = pe.ConditionCalculationType ?? "";
        let type, rate;
        if (calcType === "A") {
            type = "percent";
            rate = Math.abs(pe.ConditionRateRatio ?? 0);
        } else if (calcType === "B") {
            type = "absolute";
            rate = Math.abs(pe.ConditionRateAmount ?? 0);
        } else if (calcType === "C") {
            type = "quantity";
            rate = Math.abs(pe.ConditionRateAmount ?? 0);
        } else {
            type = "other";
            rate = Math.abs(pe.ConditionRateAmount ?? pe.ConditionRateRatio ?? 0);
        }

        const discount = {
            code:  pe.ConditionType ?? "",
            group: group,
            type:  type,
            rate:  rate,
            value: Math.abs(pe.ConditionAmount ?? 0)
        };

        if (calcType === "C" && pe.ConditionBaseQuantity) {
            discount.proRateUnitNr = pe.ConditionBaseQuantity;
        }

        return discount;
    };

    const buildSubtotalDiscount = (subtotalField, subtotalAmount, group) => ({
        code:  subtotalField,
        group: group,
        type:  "absolute",
        rate:  Math.abs(subtotalAmount),
        value: Math.abs(subtotalAmount)
    });

    const buildTax = (pe) => {
        const isAbsolute = pe.ConditionCalculationType === "B";
        return {
            code:     pe.ConditionType ?? "",
            rate:     isAbsolute
                          ? Math.abs(pe.ConditionRateAmount ?? 0)
                          : Math.abs(pe.ConditionRateRatio ?? 0),
            value:    Math.abs(pe.ConditionAmount ?? 0),
            absolute: isAbsolute
        };
    };

    const buildSubtotalTax = (subtotalField, subtotalAmount) => ({
        code:     subtotalField,
        rate:     Math.abs(subtotalAmount),
        value:    Math.abs(subtotalAmount),
        absolute: true
    });

    const resolveBasePrice = (pricingElements, strategy, configValue, item) => {
        if (strategy === STRATEGY.SUBTOTAL) {
            const field = toSubtotalField(configValue);
            const total = Math.abs(item[field] ?? 0);
            const qty = (item.RequestedQuantity ?? 0) > 0 ? item.RequestedQuantity : 1;
            return total / qty;
        }
        const pe = strategy === STRATEGY.PRICING_PROCEDURE_STEP
            ? pricingElements.find(p => matchesPricingProcedureStep(p, [configValue]))
            : pricingElements.find(p => matchesConditionType(p, [configValue]));
        if (!pe) return 0;
        const baseQty = (pe.ConditionBaseQuantity ?? 0) > 0 ? pe.ConditionBaseQuantity : 1;
        return Math.abs(pe.ConditionAmount ?? 0) / baseQty;
    };

    const resolveDiscounts = (pricingElements, strategy, configValues, group, item) => {
        if (strategy === STRATEGY.SUBTOTAL) {
            const subtotalField = toSubtotalField(configValues[0]);
            if (!subtotalField) return [];
            const amount = item[subtotalField] ?? 0;
            if (amount === 0) return [];
            return [buildSubtotalDiscount(subtotalField, amount, group)];
        }
        const matched = strategy === STRATEGY.PRICING_PROCEDURE_STEP
            ? pricingElements.filter(pe => matchesPricingProcedureStep(pe, configValues))
            : pricingElements.filter(pe => matchesConditionType(pe, configValues));
        return matched.map(pe => buildDiscount(pe, group));
    };

    const resolveTaxes = (pricingElements, strategy, configValues, item) => {
        if (strategy === STRATEGY.SUBTOTAL) {
            const subtotalField = toSubtotalField(configValues[0]);
            if (!subtotalField) return [];
            const amount = item[subtotalField] ?? 0;
            if (amount === 0) return [];
            return [buildSubtotalTax(subtotalField, amount)];
        }
        const matched = strategy === STRATEGY.PRICING_PROCEDURE_STEP
            ? pricingElements.filter(pe => matchesPricingProcedureStep(pe, configValues))
            : pricingElements.filter(pe => matchesConditionType(pe, configValues));
        return matched.map(buildTax);
    };

    const basePriceStrategy      = getConfig("entry.basePrice.strategy");
    const basePriceValue         = getConfig("entry.basePrice.value");

    const entryDiscountStrategy  = getConfig("entry.discount.strategy");
    const entryDiscountValues    = getConfigList("entry.discount.value");

    const headerDiscountStrategy = getConfig("header.discount.strategy");
    const headerDiscountValues   = getConfigList("header.discount.value");

    const entryTaxStrategy       = getConfig("entry.tax.strategy");
    const entryTaxValues         = getConfigList("entry.tax.value");

    const items = s4Response._Item ?? [];

    const entries = items.map(item => {
        const itemRef = item.SalesOrderItemText ?? item.SalesOrderItem ?? "";
        const pricingElements = item._ItemPricingElement ?? [];

        const basePrice = resolveBasePrice(pricingElements, basePriceStrategy, basePriceValue, item);

        const appliedDiscounts = [
            ...resolveDiscounts(pricingElements, entryDiscountStrategy,  entryDiscountValues,  "entryDiscount",  item),
            ...resolveDiscounts(pricingElements, headerDiscountStrategy, headerDiscountValues, "headerDiscount", item)
        ];

        const appliedTaxes = resolveTaxes(pricingElements, entryTaxStrategy, entryTaxValues, item);

        return {
            id: itemRef,
            costs: [
                {
                    type: "product",
                    basePrice: basePrice,
                    appliedDiscounts: appliedDiscounts,
                    appliedTaxes: appliedTaxes
                }
            ]
        };
    });

    const freightBasePriceStrategy  = getConfig("header.freight.basePrice.strategy");
    const freightBasePriceValues    = getConfigList("header.freight.basePrice.value");

    const freightDiscountStrategy   = getConfig("header.freight.discount.strategy");
    const freightDiscountValues     = getConfigList("header.freight.discount.value");

    const freightTaxStrategy        = getConfig("header.freight.tax.strategy");
    const freightTaxValues          = getConfigList("header.freight.tax.value");

    let shipmentCost = null;

    if (freightBasePriceStrategy && freightBasePriceValues.length > 0) {
        const headerPricingElements = s4Response._PricingElement ?? [];

        const freightPEs = freightBasePriceStrategy === STRATEGY.PRICING_PROCEDURE_STEP
            ? headerPricingElements.filter(pe => matchesPricingProcedureStep(pe, freightBasePriceValues))
            : headerPricingElements.filter(pe => matchesConditionType(pe, freightBasePriceValues));

        const freightBasePrice = freightPEs.reduce(
            (sum, pe) => sum + Math.abs(pe.ConditionAmount ?? 0), 0
        );

        const freightDiscounts = freightDiscountStrategy && freightDiscountValues.length > 0
            ? (() => {
                const matched = freightDiscountStrategy === STRATEGY.PRICING_PROCEDURE_STEP
                    ? headerPricingElements.filter(pe => matchesPricingProcedureStep(pe, freightDiscountValues))
                    : headerPricingElements.filter(pe => matchesConditionType(pe, freightDiscountValues));
                return matched.map(pe => buildDiscount(pe, "shipmentDiscount"));
            })()
            : [];

        const freightTaxes = freightTaxStrategy && freightTaxValues.length > 0
            ? (() => {
                const matched = freightTaxStrategy === STRATEGY.PRICING_PROCEDURE_STEP
                    ? headerPricingElements.filter(pe => matchesPricingProcedureStep(pe, freightTaxValues))
                    : headerPricingElements.filter(pe => matchesConditionType(pe, freightTaxValues));
                return matched.map(buildTax);
            })()
            : [];

        shipmentCost = {
            costLevel: "global",
            costs: [
                {
                    type: "shippingFee",
                    basePrice: freightBasePrice,
                    appliedDiscounts: freightDiscounts,
                    appliedTaxes: freightTaxes
                }
            ]
        };
    }

    const operationData = {
        currencyCode: currencyCode,
        entries: entries
    };

    if (shipmentCost) {
        operationData.shipmentCosts = shipmentCost;
    }

    const result = {
        data: {
            operations: [
                {
                    operationId: "passCalculationResult",
                    data: operationData
                }
            ]
        }
    };

    console.log("[s4ordersimulationInbound] output: " + JSON.stringify(result, null, 2));
    return result;
};
