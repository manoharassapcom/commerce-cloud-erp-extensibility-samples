export const handler = (input, configuration) => {
    console.log("[s4ordersimulationOutbound] input: " + JSON.stringify(input, null, 2));
    const data = input?.data ?? {};
    const configMap = (configuration && typeof configuration === "object") ? configuration : {};
    const storeId = input?.commerceContext?.storeId?.trim() ?? "";
    const prefix = `${storeId}.`;

    const salesOrderType = configMap[`${prefix}SalesOrderType`]?.trim() ?? "";

    const soldToCode = "AG";
    const shipToCode = "WE";
    const billToCode = "RE";
    const payerCode  = "RG";

    const {
        currency = {},
        locale = "",
        salesArea = {},
        salesPartners = [],
        entries = [],
        shipments = [],
        addresses = []
    } = data;

    const currencyCode = currency?.code ?? "";

    const shipment = shipments[0] ?? null;
    const plant = shipment?.fulfillmentSiteId ?? null;
    const shippingCondition = shipment?.shippingConditionCode ?? "";

    const shipToAddress = addresses.find(a => a.type === "shipTo") ?? null;
    const billToAddress = addresses.find(a => a.type === "billTo") ?? null;

    const correspondenceLanguage = locale.split("-")[0] ?? "";

    const partnerMap = {};
    salesPartners.forEach(p => {
        if (p.functionCode) {
            partnerMap[p.functionCode] = p.customerNumber ?? "";
        }
    });

    const soldToParty = partnerMap[soldToCode] || configMap[`${prefix}DefaultSoldToParty`]?.trim() || "";

    const items = entries.map(entry => {
        const item = {
            SalesOrderItemText: entry.id ?? "",
            Product: entry.productId ?? "",
            RequestedQuantity: entry.quantity ?? 0,
            RequestedQuantityISOUnit: entry.salesMeasureUnit?.isoCode ?? "",
            _ItemPricingElement: []
        };
        if (plant) item.Plant = plant;
        return item;
    });

    const partners = salesPartners
        .filter(p => p.functionCode !== soldToCode)
        .map(p => {
            if (p.functionCode === payerCode) {
                return {
                    PartnerFunction: p.functionCode ?? "",
                    Customer: p.customerNumber ?? ""
                };
            }

            const partner = {
                PartnerFunction: p.functionCode ?? "",
                Customer: p.customerNumber ?? "",
                CorrespondenceLanguage: correspondenceLanguage
            };

            if (p.functionCode === shipToCode) {
                const postalAddress = shipToAddress?.postalAddress ?? null;
                const orgName = shipToAddress?.organizationName ?? null;
                if (orgName?.orgNameLine1)                    partner.BusinessPartnerName1 = orgName.orgNameLine1;
                if (postalAddress?.street)                    partner.StreetName           = postalAddress.street;
                if (postalAddress?.houseNumber)               partner.HouseNumber          = postalAddress.houseNumber;
                if (postalAddress?.postCode)                  partner.PostalCode           = postalAddress.postCode;
                if (postalAddress?.district?.name)            partner.CityName             = postalAddress.district.name;
                if (postalAddress?.primaryRegion?.shortCode)  partner.Region               = postalAddress.primaryRegion.shortCode;
                if (postalAddress?.country?.code)             partner.Country              = postalAddress.country.code;
            }

            if (p.functionCode === billToCode) {
                const addr = billToAddress ?? shipToAddress;
                const postalAddress = addr?.postalAddress ?? null;
                const orgName = addr?.organizationName ?? null;
                if (orgName?.orgNameLine1)                    partner.BusinessPartnerName1 = orgName.orgNameLine1;
                if (postalAddress?.street)                    partner.StreetName           = postalAddress.street;
                if (postalAddress?.houseNumber)               partner.HouseNumber          = postalAddress.houseNumber;
                if (postalAddress?.postCode)                  partner.PostalCode           = postalAddress.postCode;
                if (postalAddress?.district?.name)            partner.CityName             = postalAddress.district.name;
                if (postalAddress?.primaryRegion?.shortCode)  partner.Region               = postalAddress.primaryRegion.shortCode;
                if (postalAddress?.country?.code)             partner.Country              = postalAddress.country.code;
            }

            return partner;
        });

    const result = {
        SalesOrderType: salesOrderType,
        SalesOrganization: salesArea.salesOrganization ?? "",
        DistributionChannel: salesArea.distributionChannel ?? "",
        OrganizationDivision: salesArea.division ?? "",
        SoldToParty: soldToParty,
        TransactionCurrency: currencyCode,
        _Item: items,
        _Partner: partners,
        _PricingElement: []
    };
    if (shippingCondition) result.ShippingCondition = shippingCondition;
    console.log("[s4ordersimulationOutbound] output: " + JSON.stringify(result, null, 2));
    return result;
};
